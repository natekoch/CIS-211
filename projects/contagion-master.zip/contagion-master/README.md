# Contagion (CIS 211 project)
A  simple grid model of contagion
